const readline = require('readline');

class Carro {
  constructor() {
    this.capacidadeDoTanque = 180;
    this.nívelDeGasolina = 0;
    this.motorLigado = false;
    this.velocidade = 0;
  }

  getNívelDeGasolina() {
    return this.nívelDeGasolina;
  }

  getCapacidadeDoTanque() {
    return this.capacidadeDoTanque;
  }

  isMotorLigado() {
    return this.motorLigado;
  }

  ligarMotor() {
    if (!this.motorLigado) {
      this.motorLigado = true;
      console.log('Motor ligado.');
    } else {
      console.log('O motor já está ligado.');
    }
  }

  desligarMotor() {
    if (this.motorLigado) {
      this.motorLigado = false;
      this.velocidade = 0;
      console.log('Motor desligado.');
    } else {
      console.log('O motor já está desligado.');
    }
  }

  acelerar(quantidade) {
    if (this.motorLigado) {
      this.velocidade += quantidade;
      if (this.velocidade > this.capacidadeDoTanque) {
        this.velocidade = this.capacidadeDoTanque;
      }
      console.log(`Velocidade atual: ${this.velocidade}`);
    } else {
      console.log('Ligue o motor antes de acelerar.');
    }
  }

  frear(quantidade) {
    if (this.motorLigado) {
      this.velocidade -= quantidade;
      if (this.velocidade < 0) {
        this.velocidade = 0;
      }
      console.log(`Velocidade atual: ${this.velocidade}`);
    } else {
      console.log('Ligue o motor antes de frear.');
    }
  }

  abastecer(litros) {
    if (this.motorLigado) {
      console.log('Desligue o motor antes de abastecer.');
    } else {
      this.nívelDeGasolina += litros;
      if (this.nívelDeGasolina > this.capacidadeDoTanque) {
        this.nívelDeGasolina = this.capacidadeDoTanque;
      }
      console.log(`Nível de gasolina atual: ${this.nívelDeGasolina}`);

      const preçoGasolina = 5.0; // Preço da gasolina por litro
      const valorTotalEncherTanque = this.calcularValorEncherTanque(preçoGasolina);
      console.log(`Valor total para encher o tanque: R$${valorTotalEncherTanque}`);
    }
  }

  calcularValorEncherTanque(preçoGasolina) {
    const litrosFaltantes = this.capacidadeDoTanque - this.nívelDeGasolina;
    const valorTotal = litrosFaltantes * preçoGasolina;
    return valorTotal;
  }
}

const meuCarro = new Carro();

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

console.log('Bem-vindo ao simulador de carro!');
console.log('Opções:');
console.log('Digite 1 para ligar o motor');
console.log('Digite 2 para desligar o motor');
console.log('Digite 3 para acelerar');
console.log('Digite 4 para frear');
console.log('Digite 5 para abastecer');
console.log('Digite 6 para sair');

rl.question('Escolha uma ação: ', (acao) => {
  switch (acao) {
    case '1':
      if (!meuCarro.isMotorLigado()) {
        meuCarro.ligarMotor();
        console.log('Motor ligado. Agora você pode acelerar, frear, desligar e sair.');
      } else {
        console.log('O motor já está ligado.');
      }
      rl.close();
      break;
    case '2':
      meuCarro.desligarMotor();
      console.log('Motor desligado.');
      rl.close();
      break;
    case '3':
      if (meuCarro.isMotorLigado()) {
        meuCarro.acelerar(10);
        rl.close();
      } else {
        console.log('Ligue o motor antes de acelerar.');
        rl.close();
      }
      break;
    case '4':
      if (meuCarro.isMotorLigado()) {
        meuCarro.frear(10);
        rl.close();
      } else {
        console.log('Ligue o motor antes de frear.');
        rl.close();
      }
      break;
    case '5':
      rl.question('Quantos litros deseja abastecer? ', (litros) => {
        meuCarro.abastecer(parseInt(litros));
        rl.close();
      });
      break;
    case '6':
      console.log('Saindo do programa.');
      rl.close();
      break;
    default:
      console.log('Ação inválida. Tente novamente.');
      rl.close();
  }
});
